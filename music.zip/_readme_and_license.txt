Sound pack downloaded from Freesound
----------------------------------------

"Yamaha CS-30L - Space Bass"

This pack of sounds contains sounds by the following user:
 - modularsamples ( https://freesound.org/people/modularsamples/ )

You can find this pack online at: https://freesound.org/people/modularsamples/packs/17674/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 314830__modularsamples__yamaha-cs-30l-space-bass-c5-space-bass-72-127.aiff
    * url: https://freesound.org/s/314830/
    * license: Creative Commons 0
  * 314829__modularsamples__yamaha-cs-30l-space-bass-b4-space-bass-71-127.aiff
    * url: https://freesound.org/s/314829/
    * license: Creative Commons 0
  * 314828__modularsamples__yamaha-cs-30l-space-bass-a-4-space-bass-70-127.aiff
    * url: https://freesound.org/s/314828/
    * license: Creative Commons 0
  * 314827__modularsamples__yamaha-cs-30l-space-bass-a4-space-bass-69-127.aiff
    * url: https://freesound.org/s/314827/
    * license: Creative Commons 0
  * 314826__modularsamples__yamaha-cs-30l-space-bass-g4-space-bass-68-127.aiff
    * url: https://freesound.org/s/314826/
    * license: Creative Commons 0
  * 314825__modularsamples__yamaha-cs-30l-space-bass-f-4-space-bass-67-127.aiff
    * url: https://freesound.org/s/314825/
    * license: Creative Commons 0
  * 314824__modularsamples__yamaha-cs-30l-space-bass-e-4-space-bass-65-127.aiff
    * url: https://freesound.org/s/314824/
    * license: Creative Commons 0
  * 314823__modularsamples__yamaha-cs-30l-space-bass-e4-space-bass-64-127.aiff
    * url: https://freesound.org/s/314823/
    * license: Creative Commons 0
  * 314822__modularsamples__yamaha-cs-30l-space-bass-d-4-space-bass-63-127.aiff
    * url: https://freesound.org/s/314822/
    * license: Creative Commons 0
  * 314821__modularsamples__yamaha-cs-30l-space-bass-d4-space-bass-62-127.aiff
    * url: https://freesound.org/s/314821/
    * license: Creative Commons 0
  * 314820__modularsamples__yamaha-cs-30l-space-bass-c-4-space-bass-61-127.aiff
    * url: https://freesound.org/s/314820/
    * license: Creative Commons 0
  * 314819__modularsamples__yamaha-cs-30l-space-bass-c4-space-bass-60-127.aiff
    * url: https://freesound.org/s/314819/
    * license: Creative Commons 0
  * 314818__modularsamples__yamaha-cs-30l-space-bass-b3-space-bass-59-127.aiff
    * url: https://freesound.org/s/314818/
    * license: Creative Commons 0
  * 314817__modularsamples__yamaha-cs-30l-space-bass-a-3-space-bass-58-127.aiff
    * url: https://freesound.org/s/314817/
    * license: Creative Commons 0
  * 314816__modularsamples__yamaha-cs-30l-space-bass-a3-space-bass-57-127.aiff
    * url: https://freesound.org/s/314816/
    * license: Creative Commons 0
  * 314815__modularsamples__yamaha-cs-30l-space-bass-g3-space-bass-56-127.aiff
    * url: https://freesound.org/s/314815/
    * license: Creative Commons 0
  * 314814__modularsamples__yamaha-cs-30l-space-bass-f-3-space-bass-55-127.aiff
    * url: https://freesound.org/s/314814/
    * license: Creative Commons 0
  * 314813__modularsamples__yamaha-cs-30l-space-bass-f3-space-bass-54-127.aiff
    * url: https://freesound.org/s/314813/
    * license: Creative Commons 0
  * 314812__modularsamples__yamaha-cs-30l-space-bass-e-3-space-bass-53-127.aiff
    * url: https://freesound.org/s/314812/
    * license: Creative Commons 0
  * 314811__modularsamples__yamaha-cs-30l-space-bass-e3-space-bass-52-127.aiff
    * url: https://freesound.org/s/314811/
    * license: Creative Commons 0
  * 314810__modularsamples__yamaha-cs-30l-space-bass-d-3-space-bass-51-127.aiff
    * url: https://freesound.org/s/314810/
    * license: Creative Commons 0
  * 314809__modularsamples__yamaha-cs-30l-space-bass-d3-space-bass-50-127.aiff
    * url: https://freesound.org/s/314809/
    * license: Creative Commons 0
  * 314808__modularsamples__yamaha-cs-30l-space-bass-c-3-space-bass-49-127.aiff
    * url: https://freesound.org/s/314808/
    * license: Creative Commons 0
  * 314807__modularsamples__yamaha-cs-30l-space-bass-c3-space-bass-48-127.aiff
    * url: https://freesound.org/s/314807/
    * license: Creative Commons 0
  * 314806__modularsamples__yamaha-cs-30l-space-bass-b2-space-bass-47-127.aiff
    * url: https://freesound.org/s/314806/
    * license: Creative Commons 0
  * 314805__modularsamples__yamaha-cs-30l-space-bass-a-2-space-bass-46-127.aiff
    * url: https://freesound.org/s/314805/
    * license: Creative Commons 0
  * 314804__modularsamples__yamaha-cs-30l-space-bass-a2-space-bass-45-127.aiff
    * url: https://freesound.org/s/314804/
    * license: Creative Commons 0
  * 314803__modularsamples__yamaha-cs-30l-space-bass-g2-space-bass-44-127.aiff
    * url: https://freesound.org/s/314803/
    * license: Creative Commons 0
  * 314802__modularsamples__yamaha-cs-30l-space-bass-f-2-space-bass-43-127.aiff
    * url: https://freesound.org/s/314802/
    * license: Creative Commons 0
  * 314801__modularsamples__yamaha-cs-30l-space-bass-f2-space-bass-42-127.aiff
    * url: https://freesound.org/s/314801/
    * license: Creative Commons 0
  * 314800__modularsamples__yamaha-cs-30l-space-bass-e-2-space-bass-41-127.aiff
    * url: https://freesound.org/s/314800/
    * license: Creative Commons 0
  * 314799__modularsamples__yamaha-cs-30l-space-bass-e2-space-bass-40-127.aiff
    * url: https://freesound.org/s/314799/
    * license: Creative Commons 0
  * 314798__modularsamples__yamaha-cs-30l-space-bass-d-2-space-bass-39-127.aiff
    * url: https://freesound.org/s/314798/
    * license: Creative Commons 0
  * 314797__modularsamples__yamaha-cs-30l-space-bass-d2-space-bass-38-127.aiff
    * url: https://freesound.org/s/314797/
    * license: Creative Commons 0
  * 314796__modularsamples__yamaha-cs-30l-space-bass-c-2-space-bass-37-127.aiff
    * url: https://freesound.org/s/314796/
    * license: Creative Commons 0
  * 314795__modularsamples__yamaha-cs-30l-space-bass-c2-space-bass-36-127.aiff
    * url: https://freesound.org/s/314795/
    * license: Creative Commons 0
  * 314794__modularsamples__yamaha-cs-30l-space-bass-b1-space-bass-35-127.aiff
    * url: https://freesound.org/s/314794/
    * license: Creative Commons 0
  * 314793__modularsamples__yamaha-cs-30l-space-bass-a-1-space-bass-34-127.aiff
    * url: https://freesound.org/s/314793/
    * license: Creative Commons 0
  * 314792__modularsamples__yamaha-cs-30l-space-bass-a1-space-bass-33-127.aiff
    * url: https://freesound.org/s/314792/
    * license: Creative Commons 0
  * 314791__modularsamples__yamaha-cs-30l-space-bass-g1-space-bass-32-127.aiff
    * url: https://freesound.org/s/314791/
    * license: Creative Commons 0
  * 314790__modularsamples__yamaha-cs-30l-space-bass-f-1-space-bass-31-127.aiff
    * url: https://freesound.org/s/314790/
    * license: Creative Commons 0
  * 314789__modularsamples__yamaha-cs-30l-space-bass-f1-space-bass-30-127.aiff
    * url: https://freesound.org/s/314789/
    * license: Creative Commons 0
  * 314788__modularsamples__yamaha-cs-30l-space-bass-e-1-space-bass-29-127.aiff
    * url: https://freesound.org/s/314788/
    * license: Creative Commons 0


