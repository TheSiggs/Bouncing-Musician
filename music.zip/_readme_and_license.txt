Sound pack downloaded from Freesound
----------------------------------------

"Yamaha CS-30L - Straight Guitar"

This pack of sounds contains sounds by the following user:
 - modularsamples ( https://freesound.org/people/modularsamples/ )

You can find this pack online at: https://freesound.org/people/modularsamples/packs/17675/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 314879__modularsamples__yamaha-cs-30l-straight-guitar-c6-straight-guitar-84-127.aiff
    * url: https://freesound.org/s/314879/
    * license: Creative Commons 0
  * 314878__modularsamples__yamaha-cs-30l-straight-guitar-b5-straight-guitar-83-127.aiff
    * url: https://freesound.org/s/314878/
    * license: Creative Commons 0
  * 314877__modularsamples__yamaha-cs-30l-straight-guitar-a-5-straight-guitar-82-127.aiff
    * url: https://freesound.org/s/314877/
    * license: Creative Commons 0
  * 314876__modularsamples__yamaha-cs-30l-straight-guitar-a5-straight-guitar-81-127.aiff
    * url: https://freesound.org/s/314876/
    * license: Creative Commons 0
  * 314875__modularsamples__yamaha-cs-30l-straight-guitar-g5-straight-guitar-80-127.aiff
    * url: https://freesound.org/s/314875/
    * license: Creative Commons 0
  * 314874__modularsamples__yamaha-cs-30l-straight-guitar-f-5-straight-guitar-79-127.aiff
    * url: https://freesound.org/s/314874/
    * license: Creative Commons 0
  * 314873__modularsamples__yamaha-cs-30l-straight-guitar-f5-straight-guitar-78-127.aiff
    * url: https://freesound.org/s/314873/
    * license: Creative Commons 0
  * 314872__modularsamples__yamaha-cs-30l-straight-guitar-e-5-straight-guitar-77-127.aiff
    * url: https://freesound.org/s/314872/
    * license: Creative Commons 0
  * 314871__modularsamples__yamaha-cs-30l-straight-guitar-e5-straight-guitar-76-127.aiff
    * url: https://freesound.org/s/314871/
    * license: Creative Commons 0
  * 314870__modularsamples__yamaha-cs-30l-straight-guitar-d-5-straight-guitar-75-127.aiff
    * url: https://freesound.org/s/314870/
    * license: Creative Commons 0
  * 314869__modularsamples__yamaha-cs-30l-straight-guitar-d5-straight-guitar-74-127.aiff
    * url: https://freesound.org/s/314869/
    * license: Creative Commons 0
  * 314868__modularsamples__yamaha-cs-30l-straight-guitar-c-5-straight-guitar-73-127.aiff
    * url: https://freesound.org/s/314868/
    * license: Creative Commons 0
  * 314867__modularsamples__yamaha-cs-30l-straight-guitar-c5-straight-guitar-72-127.aiff
    * url: https://freesound.org/s/314867/
    * license: Creative Commons 0
  * 314866__modularsamples__yamaha-cs-30l-straight-guitar-b4-straight-guitar-71-127.aiff
    * url: https://freesound.org/s/314866/
    * license: Creative Commons 0
  * 314865__modularsamples__yamaha-cs-30l-straight-guitar-a-4-straight-guitar-70-127.aiff
    * url: https://freesound.org/s/314865/
    * license: Creative Commons 0
  * 314864__modularsamples__yamaha-cs-30l-straight-guitar-a4-straight-guitar-69-127.aiff
    * url: https://freesound.org/s/314864/
    * license: Creative Commons 0
  * 314863__modularsamples__yamaha-cs-30l-straight-guitar-g4-straight-guitar-68-127.aiff
    * url: https://freesound.org/s/314863/
    * license: Creative Commons 0
  * 314862__modularsamples__yamaha-cs-30l-straight-guitar-f-4-straight-guitar-67-127.aiff
    * url: https://freesound.org/s/314862/
    * license: Creative Commons 0
  * 314861__modularsamples__yamaha-cs-30l-straight-guitar-f4-straight-guitar-66-127.aiff
    * url: https://freesound.org/s/314861/
    * license: Creative Commons 0
  * 314860__modularsamples__yamaha-cs-30l-straight-guitar-e-4-straight-guitar-65-127.aiff
    * url: https://freesound.org/s/314860/
    * license: Creative Commons 0
  * 314859__modularsamples__yamaha-cs-30l-straight-guitar-e4-straight-guitar-64-127.aiff
    * url: https://freesound.org/s/314859/
    * license: Creative Commons 0
  * 314858__modularsamples__yamaha-cs-30l-straight-guitar-d-4-straight-guitar-63-127.aiff
    * url: https://freesound.org/s/314858/
    * license: Creative Commons 0
  * 314857__modularsamples__yamaha-cs-30l-straight-guitar-d4-straight-guitar-62-127.aiff
    * url: https://freesound.org/s/314857/
    * license: Creative Commons 0
  * 314856__modularsamples__yamaha-cs-30l-straight-guitar-c-4-straight-guitar-61-127.aiff
    * url: https://freesound.org/s/314856/
    * license: Creative Commons 0
  * 314855__modularsamples__yamaha-cs-30l-straight-guitar-c4-straight-guitar-60-127.aiff
    * url: https://freesound.org/s/314855/
    * license: Creative Commons 0
  * 314854__modularsamples__yamaha-cs-30l-straight-guitar-b3-straight-guitar-59-127.aiff
    * url: https://freesound.org/s/314854/
    * license: Creative Commons 0
  * 314853__modularsamples__yamaha-cs-30l-straight-guitar-a-3-straight-guitar-58-127.aiff
    * url: https://freesound.org/s/314853/
    * license: Creative Commons 0
  * 314852__modularsamples__yamaha-cs-30l-straight-guitar-a3-straight-guitar-57-127.aiff
    * url: https://freesound.org/s/314852/
    * license: Creative Commons 0
  * 314851__modularsamples__yamaha-cs-30l-straight-guitar-g3-straight-guitar-56-127.aiff
    * url: https://freesound.org/s/314851/
    * license: Creative Commons 0
  * 314850__modularsamples__yamaha-cs-30l-straight-guitar-f-3-straight-guitar-55-127.aiff
    * url: https://freesound.org/s/314850/
    * license: Creative Commons 0
  * 314849__modularsamples__yamaha-cs-30l-straight-guitar-f3-straight-guitar-54-127.aiff
    * url: https://freesound.org/s/314849/
    * license: Creative Commons 0
  * 314848__modularsamples__yamaha-cs-30l-straight-guitar-e-3-straight-guitar-53-127.aiff
    * url: https://freesound.org/s/314848/
    * license: Creative Commons 0
  * 314847__modularsamples__yamaha-cs-30l-straight-guitar-e3-straight-guitar-52-127.aiff
    * url: https://freesound.org/s/314847/
    * license: Creative Commons 0
  * 314846__modularsamples__yamaha-cs-30l-straight-guitar-d-3-straight-guitar-51-127.aiff
    * url: https://freesound.org/s/314846/
    * license: Creative Commons 0
  * 314845__modularsamples__yamaha-cs-30l-straight-guitar-d3-straight-guitar-50-127.aiff
    * url: https://freesound.org/s/314845/
    * license: Creative Commons 0
  * 314844__modularsamples__yamaha-cs-30l-straight-guitar-c-3-straight-guitar-49-127.aiff
    * url: https://freesound.org/s/314844/
    * license: Creative Commons 0
  * 314843__modularsamples__yamaha-cs-30l-straight-guitar-c3-straight-guitar-48-127.aiff
    * url: https://freesound.org/s/314843/
    * license: Creative Commons 0
  * 314842__modularsamples__yamaha-cs-30l-straight-guitar-b2-straight-guitar-47-127.aiff
    * url: https://freesound.org/s/314842/
    * license: Creative Commons 0
  * 314841__modularsamples__yamaha-cs-30l-straight-guitar-a-2-straight-guitar-46-127.aiff
    * url: https://freesound.org/s/314841/
    * license: Creative Commons 0
  * 314840__modularsamples__yamaha-cs-30l-straight-guitar-a2-straight-guitar-45-127.aiff
    * url: https://freesound.org/s/314840/
    * license: Creative Commons 0
  * 314839__modularsamples__yamaha-cs-30l-straight-guitar-g2-straight-guitar-44-127.aiff
    * url: https://freesound.org/s/314839/
    * license: Creative Commons 0
  * 314838__modularsamples__yamaha-cs-30l-straight-guitar-f-2-straight-guitar-43-127.aiff
    * url: https://freesound.org/s/314838/
    * license: Creative Commons 0
  * 314837__modularsamples__yamaha-cs-30l-straight-guitar-f2-straight-guitar-42-127.aiff
    * url: https://freesound.org/s/314837/
    * license: Creative Commons 0
  * 314836__modularsamples__yamaha-cs-30l-straight-guitar-e-2-straight-guitar-41-127.aiff
    * url: https://freesound.org/s/314836/
    * license: Creative Commons 0
  * 314835__modularsamples__yamaha-cs-30l-straight-guitar-e2-straight-guitar-40-127.aiff
    * url: https://freesound.org/s/314835/
    * license: Creative Commons 0
  * 314834__modularsamples__yamaha-cs-30l-straight-guitar-d-2-straight-guitar-39-127.aiff
    * url: https://freesound.org/s/314834/
    * license: Creative Commons 0
  * 314833__modularsamples__yamaha-cs-30l-straight-guitar-d2-straight-guitar-38-127.aiff
    * url: https://freesound.org/s/314833/
    * license: Creative Commons 0
  * 314832__modularsamples__yamaha-cs-30l-straight-guitar-c-2-straight-guitar-37-127.aiff
    * url: https://freesound.org/s/314832/
    * license: Creative Commons 0
  * 314831__modularsamples__yamaha-cs-30l-straight-guitar-c2-straight-guitar-36-127.aiff
    * url: https://freesound.org/s/314831/
    * license: Creative Commons 0


